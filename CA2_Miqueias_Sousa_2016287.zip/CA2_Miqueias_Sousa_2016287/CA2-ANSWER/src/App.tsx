import React from "react";
import { RouteComponentProps } from 'react-router';
import './App.css';
import ListView from './component/list_view/list_view';
import Link from './component/link/link';
import CommunityInfo from './component/community_info/community_info';
import Header from './component/header/header';


interface Props {
	
}

interface State {
	links : any;
}


class App extends React.Component< RouteComponentProps<any>, State > {
	
	constructor(props : RouteComponentProps) {
        super(props);
		this.state = {
			links : [],
		};
    }
	
	componentDidMount(){
		if(!(window as any).__token){
			this.props.history.push("/sign_in");
		}
		this.fetchAllLinks();
	}
	
	
	render() {
		
		return (
			<div>
				<Header token={(window as any).__token}></Header>
			<div className="App">
				
				<div className="Link_detail">
					<div className="Search_box">
						<input type="text" placeholder="Search" />
					</div>
					<div>
						<ListView 
							items={this.state.links}
							renderItem={(item:any) => <Link id={item.id} title={item.title} url={item.url} commentCount={item.commentCount} userName={item.userName }  userId={item.userId } date={item.dateTime} score={item.score} onUpvote={ (id: number) => console.log( "Upvote link with ID", id ) } />}
						/>
					</div>
				</div>
				<div className="Community_detail">
					<CommunityInfo/>
				</div>
			</div>
			</div>
		);
	}
	
	fetchAllLinks() {
		
        fetch("/api/v1/links")
            .then((result) => result.json())
            .then((result) => result)
            .then((linksTemp) => {
				
				for(var i =0; i < linksTemp.length; i++){
					linksTemp[i]['commentCount'] = linksTemp[i].comments.length;
					linksTemp[i]['score'] = 0;
					for(var j =0; j < linksTemp[i].votes; j++){
						if(linksTemp[i].votes[j].isPositive){
							linksTemp[i]['score'] += 1;
						}else{
							linksTemp[i]['score'] -= 1;
						}
					}
					
					linksTemp[i]['userName'] = linksTemp[i].user.name;
					linksTemp[i]['userId'] = linksTemp[i].user.id;
				}
				
                this.setState({ links : linksTemp })
            })
            .catch((error) => console.log(error));
    }

}



export default App;