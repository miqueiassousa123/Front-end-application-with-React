import React from "react";
import './linkEntry.css';
import arrow from '../../arrow.png';
import { Link } from "react-router-dom";

interface Props {
	id?: number;
	title : string;
	url: string;
	commentCount?: number;
	date?: any;
	userName?: string;
	userId?: number;
	score?: number;
	onUpvote? :any;
	onDownvote? :any;
}


function LinkEntry(props : Props) {
  
	return	(
		<div className="Link">
			{ typeof props.score !== "undefined" && typeof props.score !== null && <div className="VoteBox">
				<div className="imageDiv" > <img onClick={ props.onUpvote } className="upsideArrow" src={arrow} /> </div>
				<div className="imageDiv" > {props.score}</div>
				<div className="imageDiv" > <img onClick={ props.onDownvote } className="downsideArrow" src={arrow} /> </div>
			</div> }
			<div className="DetailBox">
				{ props.userName && props.date && <div>Posted by u/<Link to={"/user/"+ props.userId}>{props.userName}</Link> <span> 3 hours ago</span></div> } 
				<Link to={"/link/"+ props.id}><h2 className="h2">{props.title}</h2></Link>
				<h6 className="h6"><a href={props.url}>{props.url}</a></h6>
				
				{ typeof props.commentCount !== "undefined" && typeof props.commentCount !== null &&  <div className="comment">{props.commentCount} comments</div> } 
			</div>
			<div className="Clear" ></div>
		</div>
		
	)

}

export default LinkEntry;