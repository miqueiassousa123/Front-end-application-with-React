import React , { Component } from 'react';
import Link from '../../component/link/link';


interface Props {
	items : any;
	renderItem : any;
}


interface State {
	
}


class ListView extends Component<Props, State> {
	
	constructor(props : Props) {
        super(props);
    }
	
	
	render() {
		return (
		      this.props.items.map( this.props.renderItem )
		);
	}
	
}


export default ListView;