import React , { Component } from 'react';
import * as joi from "joi";
import { Login }  from '../login/login';
import { SignUp }  from '../signup/signup';
import Header from '../header/header';


const credentialSchema = {
    email: joi.string().email().required(),
    password: joi.string().min(3).max(30).required()
};

interface SignInOrSignUpProps {
	isSignIn?: boolean;
}

interface SignInOrSignUpState {
}


class SignInOrSignUp extends Component<SignInOrSignUpProps, SignInOrSignUpState>  {
	
	 public constructor(props: SignInOrSignUpProps) {
        super(props);
    }
	
	render() {
		return (
			<div>
				<Header token={(window as any).__token}></Header>
				<div >
					{ this.props.isSignIn ? <Login />  : <SignUp /> }
				</div>
			</div>
		);
	}
}

export default SignInOrSignUp;

