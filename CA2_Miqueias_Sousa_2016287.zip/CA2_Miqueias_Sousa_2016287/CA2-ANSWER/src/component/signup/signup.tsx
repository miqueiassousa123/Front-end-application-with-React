import React , { Component } from 'react';
import * as joi from "joi";
//import createHistory from 'history/createBrowserHistory';
import { withRouter } from 'react-router'
import * as H from 'history';

const credentialSchema = {
    email: joi.string().email().required(),
    password: joi.string().min(3).max(30).required()
};

interface SignUpProps {
	history: H.History;
}

interface SignUpState {
	name : string;
    email: string;
    password: string;
	bio: string;
    error: string | null;
}


class SignUpInternal extends Component<SignUpProps, SignUpState>  {
	
	 public constructor(props: SignUpProps) {
        super(props);
		this.state = {
            email: "",
            password: "",
			name: "",
			bio: "",
			error: null
        };
    }
	
	render() {
		
		const signInDiv : React.CSSProperties =  {
			width: "25%",
			margin: "0 auto",
			padding : "2%",
			border: "1px solid",
			marginTop: "50px",
		}
		
		const button : React.CSSProperties =  {
			height: "30px",
			width: "98%",
			margin: "0 auto",
			background: "white",
			border: "1px solid",
			cursor: "pointer",
			padding: "5px 15px",
			marginTop: "20px",
		}
		
		const input : React.CSSProperties =  {
			height: "20px",
			width: "calc(100% - 40px)",
			padding: "5px 15px",
			marginTop: "20px",
		}
		const center : React.CSSProperties =  {
			textAlign: "center",
			fontSize: "12px",
			color: "red",
		}
		
		return (
			<div style={signInDiv} >
				<div>
					<div style={center} >{this._renderServerErrors()}</div>
					<div style={center} >{this._renderValidationErrors()}</div>
					<div>
						<input
							style={input}
							type="text"
							placeholder="Name"
							onKeyUp={(e) => this._updateName((e as any).target.value)}
						/>
					</div>
					<div>
						<textarea
							style={input}
							placeholder="Bio"
							onKeyUp={(e) => this._updateBio((e as any).target.value)}
						/>
					</div>
					<div>
						<input
							style={input}
							type="text"
							placeholder="Email"
							onKeyUp={(e) => this._updateEmail((e as any).target.value)}
						/>
					</div>
					<div>
						<input
							style={input}
							type="password"
							placeholder="Password"
							onKeyUp={(e) => this._updatePassword((e as any).target.value)}
						/>
					</div>
					
					<div>
						<button style={button} onClick={() => this._handleSubmit()} >Sign Up</button>
					</div>
				</div>
			</div>
		);
	}
	
	private _updateBio( bio: string) {
        this.setState({ bio: bio });
    }
	
	private _updateName(name: string) {
        this.setState({ name: name });
    }
	
    private _updateEmail(email: string) {
        this.setState({ email: email });
    }
	
    private _updatePassword(password: string) {
        this.setState({ password: password });
    }
	
	
	private _renderServerErrors() {
        if (this.state.error === "OK") {
			return <div>Success</div>;
        } else {
            return <div>{this.state.error}</div>;
        }
    }
	
    private _renderValidationErrors() {
        
		const validationResult = joi.validate({
            email: this.state.email,
            password: this.state.password
        }, credentialSchema);
		
        if (validationResult.error) {
            return <div>
                {validationResult.error.details.map(d => <div>{d.message}</div>)}
            </div>;
        }
    }
	
	 private _handleSubmit() {
		
		if(this.state.email && this.state.password){
			(async () => {
			
				try {
					const token = await saveUser(this.state.email, this.state.password, this.state.bio, this.state.name);
					// Reset error
					this.setState({ error: "OK" });
					// Redirect to home page
					this.props.history.push("/sign_in");
				} catch(err) {
					this.setState({ error: err.error });
				}
			})();
		}
    }
}

export const SignUp = withRouter(props => <SignUpInternal {...props}/>);


async function saveUser(email: string, password: string, bio: string, name: string) {
    return new Promise(function (resolve, reject) {
        (async () => {
            const data = {
                email: email,
                password: password,
				bio: bio,
                name: name,
            };
            const response = await fetch(
                "/api/v1/users",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(data)
                }
            );
            const json = await response.json();
            if (response.status === 200) {
                resolve(json.token);
            } else {
                reject(json);
            }
        })();
    });
}
