import React from "react";
import './commentCSS.css';
import arrow from '../../arrow.png';

interface Props {
	id?: number;
	content : string;
	date?: any;
	userName?: string;
	userId?: number;
	onUpvote? :any;
	onDownvote? :any;
}

function Comment(props : Props) {
  
	return	(
		<div className="Comment">
			<div className="CommentVoteBox">
				<div className="imageDiv" > <img onClick={ props.onUpvote } className="upsideArrow" src={arrow} /> </div>
				<div className="imageDiv" > <img onClick={ props.onDownvote } className="downsideArrow" src={arrow} /> </div>
			</div>
			<div className="CommentDetailBox">
				{ props.userName && props.date && <h6 className="h6">{props.userName} <span> 10/03/19 15:34</span></h6> } 
				{ props.content && <h6 className="h6">{props.content}</h6> } 
			</div>
			<div className="Clear" ></div>
		</div>
		
	)

}

export default Comment;