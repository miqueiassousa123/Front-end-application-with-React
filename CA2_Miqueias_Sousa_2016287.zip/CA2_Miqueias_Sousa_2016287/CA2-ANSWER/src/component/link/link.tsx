import React , { Component } from 'react';
import LinkEntry from '../../component/link_entry/link_entry';


interface Props {
	id?: number;
	title : string;
	url: string;
	commentCount?: number;
	date?: any;
	userName?: string;
	userId?: number;
	score?: number;
	onUpvote? :any;
	onDownvote? :any;
}

interface State {
	
}


class Link extends Component<Props, State>  {
	
	constructor(props : Props) {
        super(props);
    }
	
	render() {
		return (
			<LinkEntry
				id={this.props.id}
				title={this.props.title}
				url={this.props.url}
				commentCount={this.props.commentCount}
				date={this.props.date}
				userName={this.props.userName}
				userId={this.props.userId}
				score={this.props.score}
				onUpvote = {this.props.onUpvote}
				onDownvote = {this.props.onDownvote}
			/>
		);
	}
	
}

export default Link;