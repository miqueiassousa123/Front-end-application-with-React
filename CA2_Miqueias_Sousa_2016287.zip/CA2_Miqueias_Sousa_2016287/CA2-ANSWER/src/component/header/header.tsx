import React from 'react';
import { Link } from "react-router-dom";

interface HeaderProps {
    token: any;
}

interface HeaderState {
    userId: number;
	name : string;
}

class Header extends React.Component<HeaderProps, HeaderState> {
	
	public constructor(props: HeaderProps) {
        super(props);
		this.state = {
			userId : 0,
			name : "",
		};
    }
	
	componentDidMount(){
		if(this.props.token){
			this.getLoggedUser();
		}
	}
	
	
    public render() {
		
		const headerStyle: React.CSSProperties = {
			height: "50px",
			borderBottom: "1px solid",
			paddingLeft : "50px",
			paddingRight : "50px",
		};
		
		const homeContent: React.CSSProperties = {
			float : "left",
			lineHeight : "50px",
			paddingRight: "15px",
		};
		
		const buttonContent: React.CSSProperties = {
			float : "right", 
			lineHeight : "50px",
		};
		
		const button : React.CSSProperties =  {
			height: "30px",
			background: "white",
			border: "1px solid",
			cursor: "pointer",
			padding: "5px 15px",
			marginRight: "15px",
		}
		
        return <div id="header" style={headerStyle}>
			<div style={homeContent}><Link style={{ color: "#000", textDecoration : "none" }} to="/" >Home</Link></div>
			{ !this.props.token && <div style={buttonContent}>
				<Link to="/sign_in"><button style={button} >Sign In</button></Link>
				<Link to="/sign_up"><button style={button} >Sign Up</button></Link>
			</div> }
			
			{ this.props.token && <div style={buttonContent}>
				<div style={homeContent}>User :</div>
				<div style={homeContent}><Link to={"/user/" + this.state.userId}>{this.state.name}</Link></div>
				<Link to="/sign_in"><button style={button} >Log Out</button></Link>
			</div> } 
		</div>;
    }
	
	getLoggedUser(){
		
		fetch("/api/v1/auth/profile",  { method: "POST" , headers: { 'x-auth-token': (window as any).__token } } )
            .then((result) => result.json())
            .then((result) => result)
            .then((profile) => {
				this.setState({ userId : profile.id });
				this.setState({ name : profile.name })
            })
            .catch((error) => console.log(error));
	}
	
	
	
}

export default Header;