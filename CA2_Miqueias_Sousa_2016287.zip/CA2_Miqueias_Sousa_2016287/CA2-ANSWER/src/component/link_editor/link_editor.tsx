import React , { Component } from 'react';
import { RouteComponentProps } from 'react-router';
import * as joi from "joi";
//Here we will import createHistory from 'history/createBrowserHistory';
import { withRouter } from 'react-router'
import * as H from 'history';

import Header from '../../component/header/header';

const credentialSchema = {
    title: joi.string().required(),
    url: joi.string().required(),
};


interface LinkEditorState {
	title : string;
    url: string;
    error: string | null;
}


class LinkEditor extends Component<RouteComponentProps<any>, LinkEditorState>  {
	
	 public constructor(props: RouteComponentProps) {
        super(props);
		this.state = {
            title: "",
			url: "",
			error: null
        };
    }
	
	render() {
		
		const signInDiv : React.CSSProperties =  {
			width: "25%",
			margin: "0 auto",
			padding : "2%",
			border: "1px solid",
			marginTop: "50px",
		}
		
		const button : React.CSSProperties =  {
			height: "30px",
			width: "98%",
			margin: "0 auto",
			background: "white",
			border: "1px solid",
			cursor: "pointer",
			padding: "5px 15px",
			marginTop: "20px",
		}
		
		const input : React.CSSProperties =  {
			height: "20px",
			width: "calc(100% - 40px)",
			padding: "5px 15px",
			marginTop: "20px",
		}
		const center : React.CSSProperties =  {
			textAlign: "center",
			fontSize: "12px",
			color: "red",
		}
		
		return (
		<div>
			<Header token={(window as any).__token}></Header>
			<div style={signInDiv} >
				<div>
					<div style={center} >{this._renderServerErrors()}</div>
					<div style={center} >{this._renderValidationErrors()}</div>
					<div>
						<input
							style={input}
							type="text"
							placeholder="Title"
							onKeyUp={(e) => this._updateTitle((e as any).target.value)}
						/>
					</div>
					<div>
						<textarea
							style={input}
							placeholder="URL"
							onKeyUp={(e) => this._updateUrl((e as any).target.value)}
						/>
					</div>
					<div>
						<button style={button} onClick={() => this._handleSubmit()} >Save Post</button>
					</div>
				</div>
			</div>
		</div>
		);
	}
	
	private _updateTitle(title: string) {
        this.setState({ title: title });
    }
	
    private _updateUrl(url: string) {
        this.setState({ url: url });
    }
	
	
	private _renderServerErrors() {
        if (this.state.error === "OK") {
			return <div>Success</div>;
        } else {
            return <div>{this.state.error}</div>;
        }
    }
	
    private _renderValidationErrors() {
        
		const validationResult = joi.validate({
            title: this.state.title,
            url: this.state.url
        }, credentialSchema);
		
        if (validationResult.error) {
            return <div>
                {validationResult.error.details.map(d => <div>{d.message}</div>)}
            </div>;
        }
    }
	
	 private _handleSubmit() {
		
		if(this.state.title && this.state.url){
			(async () => {
			
				try {
					const token = await saveLink(this.state.title, this.state.url);
					// Here we  Reset an error
					this.setState({ error: "OK" });
					this.props.history.push("/");
				} catch(err) {
					this.setState({ error: err.error });
				}
			})();
		}
    }
}

export default LinkEditor;


async function saveLink(title: string, url: string) {
    return new Promise(function (resolve, reject) {
        (async () => {
            const data = {
                title: title,
                url: url
            };
            const response = await fetch(
                "/api/v1/links",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
						'x-auth-token': (window as any).__token,
                    },
                    body: JSON.stringify(data)
                }
            );
            const json = await response.json();
            if (response.status === 200) {
                resolve(json.token);
            } else {
                reject(json);
            }
        })();
    });
}
