import React , { Component } from 'react';
import './community_info.css';
import { Link } from "react-router-dom";

interface CommunityInfoProps {
	
}

interface CommunityInfoState {
	userCount : number;
}

class CommunityInfo extends Component<CommunityInfoProps, CommunityInfoState> {
	
	constructor(props : CommunityInfoProps) {
        super(props);
		this.state = {
			userCount : 0,
		};
    }
	
	
	componentDidMount(){
		this.fetchUserCounts();
	}
	
	render() {
		return (
			<div className="CommunityInfo">
				<div className="DetailDiv">
					<div> r/cct </div>
					<div> {this.state.userCount} users </div>
				</div>
				<div className="ButtonDiv">
					<Link to="/link_editor"><button className="Button" >Create Post</button></Link>
				</div>
			</div>
		);
	}
	
	fetchUserCounts() {
		
        fetch("/api/v1/users/count")
            .then((result) => result.json())
            .then((result) => result)
            .then((result) => {
                this.setState({ userCount : result.count })
            })
            .catch((error) => console.log(error));
    }
}

export default CommunityInfo;