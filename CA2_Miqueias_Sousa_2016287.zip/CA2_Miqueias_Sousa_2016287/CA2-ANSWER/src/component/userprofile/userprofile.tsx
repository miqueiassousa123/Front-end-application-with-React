import React from "react";
import './userProfile.css';

interface Props {
	id: number;
	picBase64Url : string;
	name: string;
	bio: string;
}

function UserProfile(props : Props) {
  
	return	(
		<div className="UserProfile">
			<div>
				<img className="image" src={props.picBase64Url} />
			</div>
			<div className="userdetail">
				<span>{props.name}</span>
				<p>{props.bio}</p>
			</div>
		</div>
	)
}

export default UserProfile;