import React , { Component } from 'react';
import { RouteComponentProps } from 'react-router';
import * as joi from "joi";
import './link_details.css';
import Comment from '../../component/comment/comment';
import ListView from '../../component/list_view/list_view';
import Link from '../../component/link/link';
import { withRouter } from 'react-router'
import Header from '../../component/header/header';

const commentSchema = {
    comment: joi.string().required()
};


interface State {
	link : any;
	comments : any;
	comment : string;
	linkId : string;
	error: string | null;
}

class LinkDetails extends Component< RouteComponentProps<any>, State >  {
	
	constructor(props : RouteComponentProps) {
        super(props);
		this.state = {
			link : {},
			comments : [],
			comment : "",
			error : null,
			linkId :  this.props.match.params.link_id ,
		};
		
    }
	
	componentDidMount(){
		this.getLinkDetails(this.state.linkId);
	}
	
	render() {
		
		const center : React.CSSProperties =  {
			textAlign: "center",
			fontSize: "12px",
			color: "red",
		}
		
		return (
			<div>
				<Header token={(window as any).__token}></Header>
				<div className ="LinkDetails">
					<Link id={this.state.link.id} title={this.state.link.title} url={this.state.link.url} commentCount={this.state.link.commentCount} userName={this.state.link.userName}  userId={this.state.link.userId} date={this.state.link.dateTime} score={this.state.link.score} onUpvote={ (id: number) => console.log( "Upvote link with ID", id ) } onDownvote={ (id: number) => console.log("Downvote link with ID", id) }
 />
					<ListView 
						items={this.state.comments}
						renderItem={ (comment:any) => <Comment content={comment.content}  id={comment.id} userName={comment.userName} date={comment.date} onUpvote={ (id: number) => console.log( "Upvote comment with ID", id ) } onDownvote={ (id: number) => console.log("Downvote comment with ID", id) } /> }
					/>
					<div className ="addCommentDiv">
						<div style={center} >{this._renderServerErrors()}</div>
						<div style={center} >{this._renderValidationErrors()}</div>
						<textarea onKeyUp={(e) => this._updateComment((e as any).target.value)}  placeholder="Insert your comment here"></textarea>
						<button  onClick={() => this._handleSubmit()} className="Button" >Save</button>
					</div>
				</div>
			</div>
		);
	}
	
	getLinkDetails(id: string){
		
		fetch("/api/v1/links/" + id)
            .then((result) => result.json())
            .then((result) => result)
            .then((linksTemp) => {
                this.setState({ link : linksTemp })
				
					linksTemp['commentCount'] = linksTemp.comments.length;
					linksTemp['score'] = 0;
					for(var j =0; j < linksTemp.votes; j++){
						if(linksTemp.votes[j].isPositive){
							linksTemp['score'] += 1;
						}else{
							linksTemp['score'] -= 1;
						}
					}
					
					linksTemp['userName'] = linksTemp.user.name;
					linksTemp['userId'] = linksTemp.user.id;
					
				 this.setState({ comments : linksTemp.comments })
            })
            .catch((error) => console.log(error));
	}
	
	private _updateComment(comment: string) {
        this.setState({ comment: comment });
    }
	
	private _handleSubmit() {
		
		if(this.state.comment){
			(async () => {
			
				try {
					const token = await saveComment(this.state.comment, this.state.linkId);
					// Reset error
					this.setState({ error: "OK" });
					this.props.history.push("/");
				} catch(err) {
					this.setState({ error: err.error });
				}
			})();
		}
    }
	
	private _renderServerErrors() {
        if (this.state.error === "OK") {
			return <div>Success</div>;
        } else {
            return <div>{this.state.error}</div>;
        }
    }
	
    private _renderValidationErrors() {
        
		const validationResult = joi.validate({
            comment: this.state.comment,
        }, commentSchema);
		
        if (validationResult.error) {
            return <div>
                {validationResult.error.details.map(d => <div>{d.message}</div>)}
            </div>;
        }
    }
}

export default LinkDetails;

async function saveComment(comment: string, linkId : string) {
    return new Promise(function (resolve, reject) {
        (async () => {
            const data = {
				linkId : linkId,
                content: comment
            };
            const response = await fetch(
                "/api/v1/comments",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
						'x-auth-token': (window as any).__token,
                    },
                    body: JSON.stringify(data)
                }
            );
            const json = await response.json();
            if (response.status === 200) {
                resolve(json.token);
            } else {
                reject(json);
            }
        })();
    });
}
