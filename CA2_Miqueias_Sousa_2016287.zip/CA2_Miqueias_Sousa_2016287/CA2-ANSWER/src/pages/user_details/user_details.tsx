import React , { Component } from 'react';
import './user_details.css';
import Comment from '../../component/comment/comment';
import ListView from '../../component/list_view/list_view';
import LinkEntry from '../../component/link_entry/link_entry';
import UserProfile from '../../component/userprofile/userprofile';
import { RouteComponentProps } from 'react-router';
import Header from '../../component/header/header';


interface State {
	links : any;
	comments : any;
	user : any;
}

class UserDetails extends Component< RouteComponentProps<any>, State >  {
	
	constructor(props : RouteComponentProps) {
        super(props);
		this.state = {
			links : [],
			comments : [],
			user : { },
		};
		
    }
	
	componentDidMount(){
		this.getUserDetails(this.props.match.params.user_id);
	}
	
	render() {
		return (
			<div>
				<Header token={(window as any).__token}></Header>
				<div className ="UserDetails">
					<div className ="UserDetailsLinks">
						<ListView 
							items={this.state.links}
							renderItem={ (link:any) => <LinkEntry title={link.title}  id={link.id} url={link.url} /> }
						/>
						<ListView 
							items={this.state.comments}
							renderItem={ (comment:any) => <Comment content={comment.content}  id={comment.id} /> }
						/>
					</div>
				
					<div className ="UserDetailsComp">
						<UserProfile id={this.state.user.id} picBase64Url={this.state.user.pic} name={this.state.user.name} bio={this.state.user.bio} />
				</div>
				</div>
			</div>
		);
	}
	
	getUserDetails(id: string){
		
	fetch("/api/v1/users/" + id, { headers: { 'x-auth-token': (window as any).__token } } )
            .then((result) => result.json())
            .then((result) => result)
            .then((userTemp) => {
				this.setState({ user : userTemp })
                this.setState({ links : userTemp.links });
				this.setState({ comments : userTemp.comments });
            })
            .catch((error) => console.log(error));
	}
}

export default UserDetails;