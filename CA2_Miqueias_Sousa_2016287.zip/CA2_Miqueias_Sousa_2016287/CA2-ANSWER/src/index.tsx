import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import SignInOrSignUp  from './component/signin_or_signup/signin_or_signup';
import Header from './component/header/header';
import * as serviceWorker from './serviceWorker';
import { BrowserRouter , Switch, Route, Link } from "react-router-dom";
import LinkDetails from './pages/link_details/link_details';
import UserDetails from './pages/user_details/user_details';
import LinkEditor from './component/link_editor/link_editor';

ReactDOM.render(
	
    <BrowserRouter>
        <Switch>
            <Route exact path="/" component={App} />
            <Route exact path="/link/:link_id" component={LinkDetails} />
            <Route exact path="/link_editor/:link_id" component={LinkEditor} />
			<Route exact path="/link_editor" component={LinkEditor} />
			<Route exact path="/user/:user_id" component={UserDetails} />
			<Route exact path="/sign_in" render={ (routeProps) => (
				<SignInOrSignUp isSignIn={true} />
			)} />
			<Route exact path="/sign_up" render={ (routeProps) => (
				<SignInOrSignUp isSignIn={false} />
			)} />
        </Switch>
    </BrowserRouter>,
	
    document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
