self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "ede4ea1951bd52a2f5c5",
    "url": "/static/js/main.ede4ea19.chunk.js"
  },
  {
    "revision": "5de532cc1a7003291658",
    "url": "/static/js/1.5de532cc.chunk.js"
  },
  {
    "revision": "ede4ea1951bd52a2f5c5",
    "url": "/static/css/main.ed5e3d34.chunk.css"
  },
  {
    "revision": "ccc929022be42909a50d588361ecb3c9",
    "url": "/index.html"
  }
];